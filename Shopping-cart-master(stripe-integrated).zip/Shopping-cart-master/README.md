## React-Redux Ecommerce web application
this is a sample ecommerce web app made using react, redux and react router.

Live demo can be found at [https://safe-brook-53624.herokuapp.com/](https://safe-brook-53624.herokuapp.com/).

## Build Setup

1. Run `npm install` in root directory, to install all required dependencies.
2. Use `npm start` to start the application on you machin
