import React from 'react';

const emptyCategoryPageContent = () => {
    return (
        <div className={'shop-div p-4 w-100'}>
            <h5>There are currently no products. Please check back later</h5>
        </div>
    )
};

export default emptyCategoryPageContent;
