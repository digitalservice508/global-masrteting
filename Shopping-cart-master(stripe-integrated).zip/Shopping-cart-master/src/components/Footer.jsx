import React from 'react';

const footer = () => {
    return(
        <React.Fragment>
            <div className=" shop-footer text-center py-3">
                made with Love by
                <a target={'blank'} href={'http://nextelpro.com/'}> NextelPro</a>
            </div>
        </React.Fragment>
    )
};

export default footer;
